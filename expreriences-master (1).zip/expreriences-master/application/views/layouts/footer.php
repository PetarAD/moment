<footer>
  <nav class="footer-navigation">
    <ul>
      <li><a href="<?= site_url('index.php') ?>"><i class="fa fa-home" aria-hidden="true"></i>
  Начало</a></li>
      <li><a href="<?= site_url('category') ?>"><i class="fa fa-filter" aria-hidden="true"></i>
  Категории</a></li>
      <li><a href="<?= site_url('create') ?>"><i class="fa fa-calendar" aria-hidden="true"></i>
  Създай събитие</a></li>
      <li><a href="<?= site_url('admin') ?>"><i class="fa fa-lock" aria-hidden="true"></i>
  Админ</a></li>
    </ul>
  </nav>
  <ul class="social flex-3">
    <li><a href="#" target="_blank" class="facebook"></a></li>
    <li><a href="#" target="_blank" class="twitter"></a></li>
    <li><a href="#" target="_blank" class="google-plus"></a></li>
    <li><a href="#" target="_blank" class="pinterest"></a></li>
  </ul>
       </section>
  <p class="copy">Всички права запазени. <?= date('Y') ?></p>
</footer>
</div>
</body>
</html>
